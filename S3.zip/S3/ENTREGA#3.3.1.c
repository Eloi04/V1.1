#include <stdio.h>
#include <mysql/mysql.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	MYSQL *conn;
	int err;
	MYSQL_RES *result;
	MYSQL_ROW row;
	
	
	conn = mysql_init(NULL);
	if (conn == NULL) {
		printf("Error al crear la conexión: %u %s\n",
			   mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	conn = mysql_real_connect(conn, "localhost", "root", "mysql", "Championship", 0, NULL, 0);
	if (conn == NULL) {
		printf("Error al inicializar la conexión: %u %s\n",
			   mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	char playerName[50];
	printf("Introduce el nombre del jugador: ");
	scanf("%s", playerName);
	
	char query[200];
	sprintf(query, "SELECT COUNT(*) FROM Participation WHERE Player = '%s'", playerName);

	err = mysql_query(conn, query);
	if (err != 0) {
		printf("Error al consultar datos de la base de datos: %u %s\n",
			   mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	
	result = mysql_store_result(conn);
	if (result == NULL) {
		printf("Error al almacenar el resultado: %u %s\n",
			   mysql_errno(conn), mysql_error(conn));
		exit(1);
	}
	
	row = mysql_fetch_row(result);
	if (row == NULL) {
		printf("No se obtuvieron datos en la consulta\n");
	} else {
		printf("El jugador %s tiene un total de %s partidas.\n", playerName, row[0]);
	}
	

	mysql_free_result(result);
	mysql_close(conn);
	return 0;
}
